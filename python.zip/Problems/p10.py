def breakingRecords(scores):
    max = min = scores[0]
    r1 = r2 = 0
    for score in scores:
        if max<score:
            r1 += 1
            max = score 
        
        if min>score:
            r2 += 1
            min = score

    return [r1, r2]

print(breakingRecords([10, 5, 20, 20, 4, 5, 2, 25, 1]))
print(breakingRecords([3, 4, 21, 36, 10, 28, 35, 5, 24, 42]))
