def get_frequency(c):
    dic = {}
    for i in c:
        if i in dic:
            dic[i]+=1
        else:
            dic[i] = 1
    return dic


def myfun(s):
    
    letter_freq = get_frequency(s)
    freq_count = get_frequency(letter_freq.values())

    if len(freq_count) == 1:
        return "YES"

    if len(freq_count) == 2:
        min_freq, max_freq = min(freq_count), max(freq_count)

        if freq_count[min_freq] == 1 and min_freq == 1:
            return "YES"
    
        if freq_count[max_freq] == 1 and max_freq - min_freq == 1:
            return "YES"
    
    return "NO"

s = "abcdefghhgfedecba"
print(myfun(s))

