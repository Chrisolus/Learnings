class Car:
    def __str__(self):
        return "Car for display"

    def __repr__(self):
        return "Car('Toyota', 2022)"

print(Car().__str__())
print(Car().__repr__())
