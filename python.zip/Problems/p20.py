# shared = 5
days = 3
# total = 0

# for i in range(days):
#     likes = shared//2
#     shared = likes  * 3
#     total +=  likes

# print(total)

likes = 2

total = likes + sum(likes := (likes*3)//2 for _ in range(days-1))

print(total)