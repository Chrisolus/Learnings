s = "middle-Outz"
key = 2
cipher = ''
# print(ord("a") - ord("z"))
# print(ord("A") - ord("Z"))
for c in s:
    if 'a'<= c <= 'z':
        cipher += chr(((ord(c) - ord('a') + key) % 26) + ord('a'))

    elif 'A' <= c <= 'Z':
        cipher += chr(((ord(c) - ord('A') + key) % 26) + ord('A'))
    
    else:
        cipher+=c 
    
print(cipher)

# for c in s:
    # print(ord(c))