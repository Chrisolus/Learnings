# n, m, s = 5, 2 ,1
# n,m,s = 5, 2, 2

# n,m,s = 7,19,2
n,m,s = 3,7,3
# _,_,_

# for seat in range(s, s+m):
#     seat %= n
#     seat

# print(seat)
while m>0:
    m-=1
    if s==n:
        s=0
    else:
        s+=1

print(s)