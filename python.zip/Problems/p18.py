t = 1
n = 3

for i in range(n):
    if i%2 == 0 :
        t*=2
    else:
        t+=1

print(t)