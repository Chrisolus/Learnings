W = 4
val = [1,2,3] 
wt = [4, 5, 1] 

items = sorted([(val[i], wt[i]) for i in range(len(val))], key=lambda x: x[0], reverse=True)

w = v = 0

for value, weight, idx in items:
    if w + weight <= W:
        w += weight
        v += value

print(w, v)

# items = sorted([(val[i], wt[i], i) for i in range(len(val))], key=lambda x: x[0] / x[1], reverse=True)
# print(items)
# w = v = 0

# while temp:
#     i = val.index(max(temp))
    
#     temp.remove(max(temp))
#     print(i)
#     if w+wt[i] <= W :
#         w+=wt[i]
#         v+=val[i]

# print(w, v)