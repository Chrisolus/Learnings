from rest_framework.views import APIView
from rest_framework import status
from rest_framework.response import Response
from .serializer import RegisterSerializer, CustomTokenObtainPairSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView


class MyUserView(APIView):
    def get(self, request):
        return Response({"message": "API endpoint for users"})


class LoginView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


class RegisterView(APIView):
    def get_token(self, user):
        token = RefreshToken.for_user(user)
        return {
            "refresh": str(token),
            "access": str(token.access_token),
        }

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            token = self.get_token(user)
            return Response(token, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LogoutView(APIView):
    def post(self, request):
        try:
            if request.data["refresh"]:
                RefreshToken(request.data["refresh"]).blacklist()
                return Response(
                    {"message": "Logout successful"}, status=status.HTTP_200_OK
                )
            else:
                raise Exception("Token field cannot be none")
        except Exception as e:
            print(e)
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
