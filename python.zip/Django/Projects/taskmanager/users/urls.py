from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import RegisterView

urlpatterns = [
    path("refresh/", TokenRefreshView.as_view(), name="user-view"),
    path("register/", RegisterView.as_view(), name="register-view"),
    path("login/", TokenObtainPairView.as_view(), name="token-obtain-view"),
]

{
    "username":"Chrisolus",
    "email":"chris@mail.com",
    "password":"chris@tasks"
}

{
    "refresh": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc0MjgxODA1MiwiaWF0IjoxNzQyMjEzMjUyLCJqdGkiOiIxODQzZDJiZjA1OTg0OTBkYjAzZTQ4NjY5Njk0MDdhZCIsInVzZXJfaWQiOjJ9.SrCqjT2K3yoXVWyXja4sHuC5yNABMurOcY362S9yZK9MZ3dG-KazDCBSEms1t2Pr3Vw-rFS7HBTD7p6TQqdabnFhfT-5ijFKLNS82sEn3tDwawJ-Bc2GlwjFB57-pe05Jzp6mqqqwybzXn7tR7QLaOcc_TrIrix1A8FVYts68C1UigJ6wjaglZLwMIXeAoWAuuoC6M2ya1BoOB8iIAkfOeDTbirPbJexZoXEXby4lamdtjHwiVhvrT0dFE3KVvgpLVen5dj1nLLA8SpOM1ZqyDEnBqA_aABr4-Yx_P5rTIasWQnB9l5tEsgDGO9vUOU_mTJAzHcAa9Mx8OWIbBihWQ",
    "access": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzQyMjE2ODUyLCJpYXQiOjE3NDIyMTMyNTIsImp0aSI6ImY5NjllMjY1ZjU5NzQ2NmE4OGJjYzJmNTA1YzY2YmI4IiwidXNlcl9pZCI6Mn0.UBvOj20fqqHfDjYJYRmESR78gErUx0zq_OoeWuRt3nYGQosXdwkl-Qaklyzoo9709ZOJwLQNHmHtU1leAZxYxjIjgZDb5WRDXRCu_q0uHt9nUbG2KfYtVLxXPZln9lUHedvB5Ue8r9IJuDiiCJ1_j0B7PYnuEnp8J7peuMiC7yELH8F-cupVeLZW-2sLbhrVIppXklGP3s21WkH6M70YpeeKtZgYop4IxdJbC4J9U9v_kyOXLcDeVwQfbKYXTqAAcs5YKpp6EgmYqZPXqW3PY0vZ88WMBup4vN3kD6_hQFeqyWlizIKRbrCIK8rAcuks6qvAmelHcJ0bxVQSM43HtA"
}