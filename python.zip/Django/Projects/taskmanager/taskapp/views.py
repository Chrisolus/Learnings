from rest_framework.views import APIView 
from rest_framework.response import Response
from .serializers import TaskSerializer
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from .models import Task

class AuthenticatedAPIView(APIView):
    permission_classes = [IsAuthenticated]

class GetTaskView(AuthenticatedAPIView):

    def get(self, request):
        tasks = Task.objects.all()
        task_id = request.query_params.get("id")
        title = request.query_params.get("title")
        priority = request.query_params.get("priority")
        status = request.query_params.get("status")

        if task_id:
            tasks = tasks.filter(id=task_id)
        if title:
            tasks = tasks.filter(title__icontains=title)
        if priority:
            tasks = tasks.filter(priority=priority)
        if status:
            tasks = tasks.filter(status=status)

        serializer = TaskSerializer(tasks, many=True)
        return Response(serializer.data, status=200)

class TaskByIDView(AuthenticatedAPIView):
    def get(self, request, task_id):
        task = get_object_or_404(Task, id=task_id)
        serializer = TaskSerializer(task)
        return Response(serializer.data, status=200)
    
    def put(self, request, task_id): 
        task = get_object_or_404(Task, id=task_id)  
        serializer = TaskSerializer(task, data=request.data, partial=True)

        if serializer.is_valid():
            serializer.save()  
            return Response(serializer.data, status=200)  
        return Response(serializer.errors, status=400)  
    
    def delete(self, request, task_id):
        task = get_object_or_404(Task, id=task_id) 
        task.delete()  
        return Response({"message": "Task deleted successfully"}, status=204)

class AddTaskView(AuthenticatedAPIView):
    def post(self,request):
        serializer = TaskSerializer(data = request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=200)
        else:
            return Response(serializer.error, status=400)
