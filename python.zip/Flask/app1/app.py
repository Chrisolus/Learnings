from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.secret_key = "chrischris"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
db.create_all()

class users(db.Model):
    _id = db.Column('id', db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))

    def __init__(self, name, email):
        self.name = name 
        self.email = email

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/user", methods=["POST", "GET"])
def user():
    email = None 
    if "user" in session:
        if request.method == "POST":
            flash(f"Email updated for {session['user']}")
            email = session['email'] = request.form['email']
            
            found_user = users.query.filter_by(name = session['user'])
            found_user.email = email 
            db.commit()

        else:
            if 'email' in session:
                email = session['email']
                flash(f"You are logged in as {session['user']}")
        return render_template("user.html", email = email)
    else:
        flash("You are not logged in!")
        return redirect(url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        user = session["user"] = request.form["username"]
        flash(f"Logged in sucessfully!")
        found_user = users.query.filter_by(name = user).first()
        if found_user:
            session["email"] = found_user.email
        else:
            usr = users("user", None)
            db.session.add(usr)
            db.commit()
        return redirect(url_for("user"))
    else:
        if "user" in session:
            return redirect(url_for("user"))
        else:
            return render_template("login.html")

@app.route("/logout")
def logout():
    if "user" in session:
        flash(f"You are logged out , {session['user']}!")
        session.pop("user", None)
    else:
        flash(f"Session terminated. Login again!")
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)