function sendPostRequest(id) {
    // Create a hidden form dynamically
    alert(`Item ${id} will be deleted`)
    let form = document.createElement("form");
    form.method = "POST";
    form.action = "/delete";  // URL of the Flask route

    let input = document.createElement("input");
    input.type = "hidden";
    input.name = "id";
    input.value = id 

    document.body.appendChild(form);
    form.appendChild(input);

    form.submit();
}