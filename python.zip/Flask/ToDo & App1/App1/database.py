from flask import g
import sqlite3

class SqliteDB:

    dbname = None

    def __init__(self, dbname):
        self.dbname = dbname
        conn = sqlite3.connect(dbname)
        cursor = conn.cursor()

        # Create users table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL
        )
        """)

        conn.commit()
        conn.close()
        print("Database initialized successfully!")
    
    def get_connection(self):
        if "db" not in g:
            g.db = sqlite3.connect(self.dbname)
        return g.db

    def fetch_all(self):
        conn = self.get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users")
        return cur.fetchall()

    def fetch_one(self, query, params=()):
            conn = self.get_connection()
            cur = conn.cursor()
            cur.execute(query, params)
            return cur.fetchone()
    
    def add_data(self, query, params=()):
        try:
            conn = self.get_connection()
            cur = conn.cursor()
            cur.execute(query, params)
            conn.commit()
            return cur.lastrowid
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
        
    def delete_data(self, query, params=()):
        try:
            conn = self.get_connection()
            cur = conn.cursor()
            cur.execute(query, params)
            conn.commit()
            return cur.rowcount  # Returns the number of deleted rows
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return None
    
    @staticmethod
    def close_connection():
        db = g.pop("db", None)
        if db:
            db.close()