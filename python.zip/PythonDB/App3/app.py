from menu import MenuController
from database import Database 

connection = Database.init() # Create tables and Get connection from DB
menu = MenuController(connection) # Menu Setup
menu.run() # Run UI