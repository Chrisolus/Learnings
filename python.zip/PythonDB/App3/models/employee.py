from models.validators import getValidValue, getValidDate

class Employee: # Handles CRUD Operation on Employee Table

    select_query = "SELECT e.id, e.fname, e.lname, e.dob, r.name AS role, r.salary FROM Employee e LEFT JOIN Role r ON e.role = r.id"
    
    def __init__(self, connection, role):
        self.role = role
        self.con = connection
        self.table = "Employee"

    def create(self):
        print("==CREATE EMPLOYEE==")
        data = self.getUserInput()
        try:
            cursor = self.con.cursor()
            cursor.execute("INSERT INTO Employee (fname, lname, dob, role) VALUES (?,?,?,?)", tuple(data.values()))
            self.con.commit()
            return self.fetchById(cursor.lastrowid)       
        except Exception as e:
            return {'message': str(e)}
    
    def fetchById(self, id):
        try:
            cursor = self.con.cursor() 
            cursor.execute(f"{self.select_query} WHERE e.id = ?", (id,))
            return {"employees": (cursor.fetchone(),)}
        except Exception as e:
            return {'message': str(e)}
        
    def fetchBy(self, field, value):
        try:
            if field == 'role' :
                value = self.role.getValidRoleId()
            else:
                value = (value,)
            cursor = self.con.cursor()
            cursor.execute(f"{self.select_query} WHERE e.{field} = ?", value)
            return {'employees': cursor.fetchall()}
        except Exception as e:
            return {'message': str(e)}
        
    def fetchAll(self):
        try:
            cursor = self.con.cursor() 
            cursor.execute(self.select_query)
            return {'employees': cursor.fetchall()}
        except Exception as e:
            return {'message': str(e)}
  
    def updateField(self, id, field, value):
        try:
            if field == 'role':
                value = self.role.getValidRoleId()[0]
            cursor = self.con.cursor()
            cursor.execute(f"UPDATE Employee SET {field} = ? WHERE id = ?", (value, id,))
            self.con.commit()
            if cursor.rowcount <=0:
                raise Exception("No rows affected")
            else:
                return self.fetchById(id)
        except Exception as e:
            return {'message': str(e)}
    
    def delete(self, id):
        print(self.fetchById(id))
        while not (c := input("Do you want to delete the above? (y/n)>> ")).lower() == 'y' and not c.lower() == 'n': 
            print("Invalid Input")
        if c.lower() == 'y':
            cursor = self.con.cursor()
            cursor.execute("DELETE FROM Employee WHERE id = ?", (id,))
            self.con.commit()
            return {"rows" : cursor.rowcount}
        else:
            return {'message': 'Operation Aborted'}
        
    def getUserInput(self):
        fname = getValidValue(prompt="Employee first name>> ")
        lname = getValidValue(prompt="Employee last name>> ")
        dob = getValidDate()
        role_id = self.role.getValidRoleId()
        
        return {'fname': fname, 'lname': lname, 'dob': dob, 'role_id': role_id[0],}