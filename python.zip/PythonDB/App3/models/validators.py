from datetime import datetime
from database import Database

def isValidDate(date_str):
    try:
        datetime.strptime(date_str, "%d/%m/%Y")
        return True 
    except Exception:
        return False

def getValidValue(prompt):
    while not (name := input(prompt).strip()):
            print("Invalid Value")
    return name

def getValidField(tablename):
    while not (field:= input(f"Enter {tablename} Field>> ")) in Database.fields(tablename):
        print(f"Invalid Field :: Valid Fields -> {Database.fields(tablename)}")
    return field

def getValidId(tablename):
    while not (id := input(f"Enter {tablename} id>> ")).isdigit() or not (int(id) in Database.getIds(tablename)):
        print("Invalid ID")
    return id

def getValidDate():
    while not isValidDate(date:=input("Employee dob (dd/mm/yyyy)>> ")):
        print("Invalid format. Try dd/mm/yyyy")
    return date

wait = lambda : input("Press any key>>")
