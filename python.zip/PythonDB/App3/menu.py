from models import Role, Employee
from services import RoleService, EmployeeService
from models.validators import wait

EmployeeService("Bane")

class MenuController:

    def __init__(self, connection): # Setting up Menu using RoleInterface and EmployeeInterface
        role = Role(connection)
        self.emp_serv = EmployeeService(Employee(connection, role))
        self.role_serv = RoleService(role)
        self.menu = {
            '1': ("Add Employee", self.emp_serv.addEmployee),
            '2': ("View Employee", self.emp_serv.viewEmployee),
            '3': ("Update Employee", self.emp_serv.updateEmployee),
            '4': ("Delete Employee", self.emp_serv.deleteEmployee),
            '5': ("Add Role", self.role_serv.addRole),
            '6': ("View Roles", self.role_serv.viewRoles),
            '7': ("Update Role", self.role_serv.updateRole),
            '8': ("Delete Role", self.role_serv.deleteRole),
            '9': ("Exit", lambda: 'exit'),
        }

    def run(self):
        while True:
            print(f"{'='*32}\n{' '*14}MENU\n{'='*32}")
            for key, (label, _) in self.menu.items(): # Display Menu
                print(f"{key}. {label}")
            print("=" * 32)

            c = input("choice>>> ")

            try:
                if self.menu.get(c)[1]() == 'exit': break # Calling corresponding function
            except Exception as e:
                print(e)
                print("Invalid Choice")
                wait()     