from models.validators import getValidId, getValidField, getValidValue, wait

class RoleService:# Handles User Input and Validations before sendng data to Role 
    def __init__(self, role):
        self.role = role

    def addRole(self):
        res = self.role.create()
        if res.get("message"):
            print(res.get("message"))
        else:
            self.printRole(res.get("roles"))
        wait()

    def viewRoles(self):
        res = self.role.fetchAll()
        if res.get('message'):
            print(res.get('message'))
        else:
            self.printRole(res.get("roles"))
        wait()

    def updateRole(self):
        self.printRole(self.role.fetchAll().get('roles'))
        print("===== UPDATE ROLE =====")
        id = getValidId(self.role.table)
        field = getValidField(self.role.table)
        value = getValidValue(f"Enter {field}>> ")
        
        res = self.role.updateField(id, field, value)
        print(res)

        if res.get('message'):
            print(res.get('message'))
        else:
            print("=====Updated Successfully======")
            self.printRole(res.get('roles'))
        wait()

    def deleteRole(self):
        self.printRole(self.role.fetchAll().get('roles'))
        print("===== DELTE ROLE =====")
        id = getValidId(self.role.table)
        res = self.role.delete(id)
        if res.get("message"):
            print(res.get('message'))
        else:
            self.printRole(self.role.fetchAll().get('roles'))
            print(f"{'='*8} {res.get('rows')} Row Deleted Successfully {'='*9}")
        wait()
    
    @staticmethod
    def printRole(roles):
        if roles:
            print(f"{'='*45}\n{" "*20}ROLES\n{'='*45}")

            print(f"{'ID':<5} {'Key':<8} {'Name':<20} {'Salary':<8}")
            print("=" * 45)
            try:
                for role in roles:
                    id, key, name, salary = role
                    print(f"{id:<5} {key:<8} {name:<20} {salary:<8}")
                print("=" * 45)
            except Exception as e:
                print(e)
        else:
            print("No data to display")