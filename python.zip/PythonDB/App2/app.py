from database import Database
from employee import Employee
from role import Role
import utils

Database.init()

wait = lambda : input("Press any key>>")

def main():

    while True:
        print(f"{'='*32}\n{' '*14}MENU\n{'='*32}")
        print("1. Add Employee") 
        print("2. View Employee") 
        print("3. Update Employee") 
        print("4. Delete Employee") 
        print("5. Add Role") 
        print("6. View Roles")
        print("7. Update Role")
        print("8. Delete Role")
        print("9. Show Employee And Role Table") 
        print("0. Exit") 
        print("=" * 32)

        c = input("choice>>> ")

        if c == "1": # Add Employee
            res = Employee.create()
            if res.get("message"):
                print(res.get("message"))
            else:
                printEmployee(res.get("employees"))
            wait()

        elif c == "2": # View Employee
            res = getEmployees()
            if res.get("message"):
                print(res.get("message"))
            else:
                printEmployee(res.get("employees"))
            wait()

        elif c == "3": # Update Employee
            printEmployee(Employee.fetchAll().get("employees"))
            res = update('Employee')
            if res.get('message'):
                print(res.get('message'))
            else:
                print("=====Updated Successfully======")
                printEmployee(res.get('employees'))
            wait()

        elif c == '4':
            delete("Employee")

        elif c == "5": # Add Role
            res = Role.create()
            if res.get("message"):
                print(res.get("message"))
            else:
                printRole(res.get("roles"))
            wait()

        elif c == "6": # View Roles
            res = Role.fetchAll()
            if res.get("message"):
                print(res.get("message"))
            else:
                printRole(res.get("roles"))
            wait()

        elif c == '7': # Update Roles
            printRole(Role.fetchAll().get('roles'))
            res = update('Role')
            if res.get('message'):
                print(res.get('message'))
            else:
                print("=====Updated Successfully======")
                printRole(res.get('roles'))
            wait() 

        elif c == '8':
            delete("Role")

        elif c == "9": # Display Role and Employee
            printEmployee(Employee.fetchAll().get("employees"))
            printRole(Role.fetchAll().get("roles"))
            wait()

        elif c == "0":
            break

        else:
            print("Invalid Choice :: Try [0-1]")
            wait()

def update(tablename):
    id = utils.getValidId(tablename)
    field = utils.getValidField(tablename)
    if field == 'key':
        value = utils.getValidRoleKey()
    elif field == 'role':
        value = utils.getValidRoleId()[0]
    elif field == 'dob':
        value = utils.getValidDate()
    else:
        value = utils.getValidValue(f"Enter {field}>> ")

    if tablename == 'Employee':
        return Employee.updateField(id, field, value)
    elif tablename == 'Role':
        return Role.updateField(id, field, value)
    else:
        return {"message": "Table Not Present"}

def getEmployees():
    while True:
        print("===== VIEW EMPLOYEE =====")
        print("1. View by ID")
        print("2. View by Field")
        print("3. View All")
        print("4. Back")
        print("="*25,)
        c = input("choice>>>")
        if c == "1":
            id = utils.getValidId("Employee")
            return Employee.fetchById(id)
        elif c == "2":
            field = utils.getValidField("Employee")
            if field == 'role':
                value = utils.getValidRoleId()[0]
            elif field == 'dob':
                value = utils.getValidDate()
            else:
                value = input("Enter value>> ")
            return Employee.fetchBy(field, value)
        elif c == "3":
            return Employee.fetchAll()
        elif c == "4":
            return None
        else:
            print("Invalid Choice :: Try [1-4]")

def delete(table):
    if table == "Role":
        printRole(Role.fetchAll().get('roles'))
    else:
        printEmployee(Employee.fetchAll().get("employees"))
    id = utils.getValidId(f'{table}')
    res = Role.delete(id) if table == "Role" else Employee.delete(id)

    if res.get("message"):
        print(res['message'])
    else:
        print(f"==== {res.get('rows')} row(s) Deleted Successfully ====")
    wait()

def printEmployee(employees):
    if employees:
        print(f"{'='*70}\n{" "*31}EMPLOYEE\n{'='*70}")
        print(f"{'ID':<5} {'Name':<20} {'DOB':<12} {'Role':<20} {'Salary':<15}")
        print("=" * 70)
        try:
            for emp in employees:
                emp_id, fname, lname, dob, role, salary = emp
                name = f"{fname} {lname}"
                print(f"{emp_id:<5} {name:<20} {dob:<12} {str(role):<20} {str(salary):<10}")
            print("=" * 70) 
        except Exception as e:
            print(e)
    else:
        print("No data to display")


def printRole(roles):
    if roles:
        print(f"{'='*45}\n{" "*20}ROLES\n{'='*45}")

        print(f"{'ID':<5} {'Key':<8} {'Name':<20} {'Salary':<8}")
        print("=" * 45)
        try:
            for role in roles:
                id, key, name, salary = role
                print(f"{id:<5} {key:<8} {name:<20} {salary:<8}")
            print("=" * 45)
        except Exception as e:
            print(e)
    else:
        print("No data to display")

main()
