from database import Database
import utils

con = Database.getConnection()

class Role:

    @staticmethod
    def create():
        print("==CREATE ROLE==")
        data = Role.getInput()
        try:
            cursor = con.cursor()
            cursor.execute("INSERT INTO Role (key, name, salary) VALUES (?,?,?)", tuple(data.values()))
            con.commit()
            return Role.fetchById(cursor.lastrowid)
        except Exception as e:
            return {'message': str(e)}
    
    @staticmethod
    def fetchAll():
        try:
            cursor = con.cursor()
            cursor.execute("SELECT * FROM Role")
            return {"roles" : cursor.fetchall()}
        except Exception as e:
            return {'message': str(e)}
    
    @staticmethod
    def fetchById(id):
        try:
            cursor = con.cursor() 
            cursor.execute(f"SELECT * FROM Role WHERE id = {id}")
            return {"roles": (cursor.fetchone(),)}
        except Exception as e:
            return {'message': str(e)}
    
    @staticmethod
    def delete(id):
        try: 
            cursor = con.cursor()
            cursor.execute(f"DELETE from Role WHERE id = ?", (id,))
            con.commit()
            if cursor.rowcount <=0:
                raise Exception("No rows affected")
            else:
                return {'rows': cursor.rowcount}
        except Exception as e:
            return {'message': str(e)}

    @staticmethod
    def updateField(id, key, value):
        try:
            cursor = con.cursor()
            cursor.execute( f"UPDATE Role SET {key} = ? WHERE id = ?", (value, id, ))
            con.commit()
            if cursor.rowcount <= 0:
                raise Exception({'message': 'No rows affected'})
            else:
                return Role.fetchById(id)
        except Exception as e:
            return {'message': str(e)}

    @staticmethod
    def getKeyId(key):
        try:
            cursor = con.cursor()
            cursor.execute("SELECT id FROM Role WHERE key = ?", (key,))
            return cursor.fetchone()
        except Exception as e:
            print("Error: ", str(e))
            return None

    @staticmethod
    def getKeys():
        try:
            cursor = con.cursor()
            cursor.execute("SELECT key FROM Role")
            return tuple(item[0] for item in cursor.fetchall()) 
        except Exception as e:
            print("Error: ", str(e))
            return None
    
    @staticmethod
    def getNames():
        try:
            cursor = con.cursor()
            cursor.execute("SELECT name FROM Role")
            return tuple(item[0] for item in cursor.fetchall()) 
        except Exception as e:
            print("Error: ", str(e))
            return None

    @staticmethod
    def getInput():
        key  = utils.getValidRoleKey()
        name = utils.getValidValue("Role Name>> ")
        
        while not (salary := input("Role Salary>> ")).isdigit():
            print("Salary should be a number")
        
        return {'key': key, 'name': name, 'salary': salary}
