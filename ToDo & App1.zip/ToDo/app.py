from flask import Flask, render_template
from routes import app_route
from database import init_db

app = Flask(__name__)
app.secret_key = "poiuytrew"

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

app.register_blueprint(app_route)
init_db(app)

if __name__ == "__main__":
    app.run(debug=True)