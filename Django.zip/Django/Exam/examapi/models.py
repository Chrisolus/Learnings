from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class User(AbstractUser):
    uid = models.CharField(max_length=255, unique=True)
    designation = models.CharField(max_length=255)
 # Provide unique related_name for default fields to avoid clashes
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='user_set_custom',  # Custom related_name to avoid clash
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='user_permissions_set_custom',  # Custom related_name to avoid clash
        blank=True
    )
    def __str__(self):
        return self.username


class Exam(models.Model):
    exam_id = models.CharField(max_length=255, unique=True)  # Unique identifier for the exam
    title = models.CharField(max_length=255)  # Title or description of the exam
    creator = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name="created_exams"
    )  # Tracks the user who created the exam
    attended_users = models.ManyToManyField(User, related_name="exams_attended")  # Tracks users who attended the exam

    def __str__(self):
        return self.title


class Question(models.Model):
    exam = models.ForeignKey(
        Exam, 
        on_delete=models.CASCADE, 
        related_name="questions"
    )  # Links a question to its exam
    text = models.TextField()  # Question text
    option_a = models.CharField(max_length=255)
    option_b = models.CharField(max_length=255)
    option_c = models.CharField(max_length=255)
    option_d = models.CharField(max_length=255)
    correct_answer = models.CharField(
        max_length=2,
        choices=[
            ("a", "Option A"),
            ("b", "Option B"),
            ("c", "Option C"),
            ("d", "Option D"),
        ],
    )  # The correct answer for the question

    def __str__(self):
        return self.text

