from django.urls import path
from rest_framework_simplejwt.views import (TokenObtainPairView, TokenRefreshPair)

urlspatterns = [
    path('api/token/', TokenObtainPairView.as_view(), name='Obtain-Auth-Token'),
    path('api/token/refresh/', TokenRefreshPair.as_view(), name='Refresh-Auth-Token'),
]