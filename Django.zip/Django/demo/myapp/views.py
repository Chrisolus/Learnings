from django.shortcuts import render, HttpResponse

# Create your views here.
def home(request):
    items = ['Apple', 'Banana', 'Cherry']
    return render(request, "home.html", {"items":items})
