from django.urls import path 
from .views import BlogAPIView 

urlpatterns = [
    path('blogs/', BlogAPIView.as_view(), name="Blogs"),
    path('blogs/<int:id>/', BlogAPIView.as_view(), name='Blog-detail'),
]
