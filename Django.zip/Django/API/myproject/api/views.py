from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Blog
from .serializers import BlogSerializer

# @api_view(['GET', 'POST', 'DELETE'])
# def blogs(request):
#     if(request.method == 'GET'):
#         blogs = Blog.objects.all()
#         serializer = BlogSerializer(blogs, many=True)
#         return Response(serializer.data);
#     if(request.method == 'POST'):
#         serializer = BlogSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#         return Response(serializer.data)
#     if(request.method == 'DELETE'):
#         print(request.body)
#         return Response(BlogSerializer(Blog.objects.all(), many=True).data)

# @api_view(['POST'])
# def postBlogs(request):
#     serializer = BlogSerializer(data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#     return Response(serializer.data)

class BlogAPIView(APIView):
    def get(self, request, **kwargs):
        blog_id = kwargs.get('id') 
        if blog_id:
            try:
                blog = Blog.objects.get(id=blog_id)
                serializer = BlogSerializer(blog)
                return Response(serializer.data, status=200)
            except Blog.DoesNotExist:
                return Response({"detail": "Blog not found"}, status=404)
        else:
            blogs = Blog.objects.all()
            serializer = BlogSerializer(blogs, many=True)
            return Response(serializer.data, status=200)

    def post(self, request):
        print("Posting")
        serializer = BlogSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, **kwargs):
        blog_id = kwargs.get('id')  
        if blog_id:
            try:
                blog = Blog.objects.get(id=blog_id)  
                blog.delete()  
                return Response({"detail": "Blog deleted successfully"}, status=200)
            except Blog.DoesNotExist:
                return Response({"detail": "Blog not found"}, status=404)
        else:
            return Response({"detail": "ID is required to delete a blog"}, status=400)
    