from django.urls import path
from .views import RegisterUser, LoginView, LogoutView
from rest_framework_simplejwt.views import TokenRefreshView

urlpatterns = [
    path("register/", RegisterUser.as_view(), name="new-user-register"),
    path("login/", LoginView.as_view(), name="token-obtain"),
    path("refresh/", TokenRefreshView.as_view(), name="token-refresh"),
    path("logout/", LogoutView.as_view(), name="token-blacklist"),
]

# {
#     "access": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzM4MTQwOTQ4LCJpYXQiOjE3MzgwNTQ0NjYsImp0aSI6ImM2M2RiY2U5N2ZmMzRjYjNhODM2NDUyNTk1ODNkYTZjIiwidXNlcl9pZCI6MTN9.PzVwJcDDjZwozMT8RGagaJD2I1mgXuzNGOjsed0r7bDTzRTA0YG_bcGJPv0ZxZ0N9VChCknjeorExcrtHUeIGeFwykpaDkQEWERsfqxqufLTxHCltUvA0eXvg3kgzaa-n5Ncjd4h5FQr-6a8EyGLmhr1mch2R4Qeof-_pPvnZNvPJfoQQ_IeQSuLLda6jV2q-iCg2j3I1B-1_hoP5eNiZFMCIEe0BnVkZ44ML7inHzYQARu1S-KQdsSLSbFaSuXi036unrL0m1FOsPiD3fbm5T5p06r46edu8cFMQ44sF9TgOVMT-UgJHgEoY6w5wG79h_jymWVuuMB9UsSP1jXiCA",
#     "refresh": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTczODIyNzM0OCwiaWF0IjoxNzM4MDU0NTQ4LCJqdGkiOiI3ZTAxNDI1NmQzY2E0MDMxYWM5M2FhZjJhMzUzZjc1NiIsInVzZXJfaWQiOjEzfQ.w7hli1FBfMg3W7uctagpBrhZgz8oVqrOvkMIZZovFWfRdcS-RXQlTtPI39vi5LF_rlGRuED2ar2evVWpVGs7WhJAumbNgI5-BwsTWNce4xRZIFiviiahorkEPbJlzLdp4IxM8Jk9qyjt8QfLrQFgKy6Dtbibofdiw7t1x8crY-BQ52ruzYJv3RIm6HLISY3UypUVjQqZRD8vzarQRkJDkZJ97qanr5RJ4RNpE5wbnbuA4GI1MXkPKzq8HaFIV9SDrH9A8kPQoTIa4_qIC19MfuAAj2dQh1DEMib3mtRlY_Cf2TXG31CiFD4dw6q_EQjB-A6OIoG2aIQ3lI2EJ32bnA",
# }
