from django.contrib import admin
from .models import Movie, Review
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User

@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'genre')

class CustomUserAdmin(UserAdmin):
    list_display = ('id', 'username', 'email', 'date_joined')

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('movie', 'user', 'review_text', 'created_at')
    fields = ('movie', 'user', 'review_text') 

admin.site.unregister(User)  # Unregister the default User model
admin.site.register(User, CustomUserAdmin)

# Register your models here.
