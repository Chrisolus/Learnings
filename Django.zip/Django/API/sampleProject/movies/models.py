from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Movie(models.Model):
    title = models.CharField(max_length=300)
    director = models.CharField(max_length=200)
    genre = models.CharField(max_length=200)
    description = models.TextField()
    poster = models.TextField()

    def __str__(self):
        return self.title


class Review(models.Model):
    user = models.ForeignKey(User, related_name="reviews", on_delete=models.CASCADE, null=True)
    movie = models.ForeignKey(Movie, related_name="reviews", on_delete=models.CASCADE, null=True)
    review_text = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.review_text


"""
{
"title": "Superman 2025",
"director": "James Gunn",
"genre": "Sci-Fi",
"des":"Superman embarks on a journey to reconcile his Kryptonian heritage with his human upbringing as Clark Kent.",
"poster": "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/078277ed-5380-4deb-b166-997beba79634/dirjtde-d46d103c-7452-4544-bf81-0bb9fde5c411.jpg/v1/fill/w_799,h_1000,q_70,strp/superman__2025__poster_1_textless_by_crillyboy25_dirjtde-pre.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NDA5NiIsInBhdGgiOiJcL2ZcLzA3ODI3N2VkLTUzODAtNGRlYi1iMTY2LTk5N2JlYmE3OTYzNFwvZGlyanRkZS1kNDZkMTAzYy03NDUyLTQ1NDQtYmY4MS0wYmI5ZmRlNWM0MTEuanBnIiwid2lkdGgiOiI8PTMyNzYifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.S_RtHHuZbMMOHXhIySDqVy3agJQLyOG3uGrEuWwO6c0"
}
"""

"""

"""
