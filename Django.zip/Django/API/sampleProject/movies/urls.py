from django.urls import path
from .views import MoviesView, AddReview

urlpatterns = [
    path('', MoviesView.as_view(), name="movies-list"),
    path('add-review/', AddReview.as_view(), name="add-movie-review")
]
