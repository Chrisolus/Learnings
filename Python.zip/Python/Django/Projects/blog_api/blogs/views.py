from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from .serializer import BlogSerializer, CommentSerializer, Blog, BlogListSerializer

class AuthenticatedAPIView(APIView):
    permission_classes = [IsAuthenticated] 

class BlogsListView(APIView):

    def get(self, request):

        blog_id = request.query_params.get('id')
        author = request.query_params.get('author')

        blogs = Blog.objects.all()
        if blog_id:
            blogs = blogs.filter(id = blog_id)
        if author:
            blogs = blogs.filter(author__username = author)         

        serializer = BlogListSerializer(blogs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
class MyBlogs(AuthenticatedAPIView):
    def get(self, request):
        blogs = Blog.objects.filter(author = request.user)
        serializer = BlogListSerializer(blogs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class BlogById(AuthenticatedAPIView):

    def get(self, request, blog_id):
        blog = get_object_or_404(Blog, id=blog_id)
        serializer = BlogSerializer(blog, context={"user": request.user})

        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def post(self, request, blog_id):
        blog = get_object_or_404(Blog, id=blog_id)
        if blog.author != request.user:
            return Response({"detail": "You do not have permission to access this blog."}, status=status.HTTP_403_FORBIDDEN)
        serializer = BlogSerializer(blog, data = request.data, partial=True)
        
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status = status.HTTP_400_BAD_REQUEST)
        
    def delete(self, request, blog_id):
        blog = get_object_or_404(Blog, id=blog_id)
        if blog.author != request.user:
            return Response({"message": "You do not have permission to modify this blog."}, status=status.HTTP_403_FORBIDDEN)
        blog.delete()
        return Response({"message":"Blog deleted successfully"}, status=status.HTTP_204_NO_CONTENT)

class PostBlogView(AuthenticatedAPIView):

    def post(self, request):
        data = request.data.copy()  
        data["author"] = request.user.username
        serializer = BlogSerializer(data = data)
        if serializer.is_valid():
            serializer.save(author = request.user)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
class CommentView(AuthenticatedAPIView):

    def get(self, request, blog_id):
        blog = get_object_or_404(Blog, id=blog_id)
        serializer = CommentSerializer(blog.comments.all(), many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, blog_id):  
        blog = get_object_or_404(Blog, id=blog_id)  
        serializer = CommentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(author=request.user, blog=blog) 
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        print(serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)