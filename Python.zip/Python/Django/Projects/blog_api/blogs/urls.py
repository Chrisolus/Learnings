from django.urls import path
from .views import BlogsListView, BlogById, PostBlogView, CommentView, MyBlogs

urlpatterns = [
    path('', BlogsListView.as_view(), name="blogs-list-view"),
    path('myblogs/',MyBlogs.as_view(), name="user-blogs-view"),
    path('<int:blog_id>/', BlogById.as_view(), name="blogs-by-id-view"),
    path('<int:blog_id>/comments/', CommentView.as_view(), name="blogs-comments-view"),
    path('add-post/', PostBlogView.as_view(), name="blog-post-view"),
]
