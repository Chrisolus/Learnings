from django.urls import path
from .views import RegisterView, LogoutView
from rest_framework_simplejwt.views import TokenRefreshView, TokenObtainPairView

urlpatterns = [
    path('refresh/', TokenRefreshView.as_view(), name="user-refresh-view"),
    path('register/', RegisterView.as_view(), name="user-register-view"),
    path('login/', TokenObtainPairView.as_view(), name="user-login-view"),
    path("logout/", LogoutView.as_view(), name="token-blacklist"),

]

{
    "username": "Chrisolus",
    "email":"chris@mail.com",
    "password":"chris@blogs"
}

{
    "refresh": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc0MzIxNTgyMSwiaWF0IjoxNzQyNjExMDIxLCJqdGkiOiJjMWI3NzZiODc2YjU0NDViYTcwMWQ3YTBiYTJjZTkwMiIsInVzZXJfaWQiOjZ9.C5iIhEm1xTgg1t7GEnGZqrFFPJIic44p9gVr0IZQKbB5vuFEoTnzg9DttNG7IQto9sR02KlDpGPNfGzTw-CF6LzW4PAnD-YvwtXUexG5i2QHglxXit72EfK0jtkBBYFsJKmM7ax_s3EOeZ3X-FAdyGojLeDo2LeDPK6aHixxNbwtT6pmhLys8qcYKFlFukdtL1K01xR2U48eBHyX0nSiniHRXpWzFz6p6HUVz74eCLldL-nB0K42ThcK1y4UfnV5BmGnpGrPUpxBJYaEVulWvnaBQTEcWxVZM2nCelz1Mj42bBtrdV0qA8D6_gnd3E4fyoYS3nP8_0t_m8hC6Pn-Dg",
    "access": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzQyNjE4MjIxLCJpYXQiOjE3NDI2MTEwMjEsImp0aSI6IjBlN2RjMDY2ODk3NzRiMmU5YjUyNjQ5NjFhMDc1N2QyIiwidXNlcl9pZCI6Nn0.Xi9bNy9HAtLNwDM02cN9SC19zoEqmHt1rzjwmy2HEVcLdbHejYXpU4xnOqmmfkLiyWujhDDfnFcHonQNECtMOcLBQvKPWquBLfhvm7orLOQdGZnPRLfZwx4Uc3ZfboN0CWnSqqsGRmP4fyNUopiZogoIKkk0TRwKttiQOqO03fAOPJXA4ifThLaJp68CmjIU_UM5jmm1NbcOlRLasG21C5HyO1A9YzMss0ZU6MqQTgBMZfif8Bi5V1Thdn8hNuPRIi2fYrw5RfHQH3EeLPGAe_pxe8QyIE8fZ4cW3Q_rybwO2FHGaugp7muLVBNHgzBqwbY7Ypzo5Z4_GH74Exru0w"
}