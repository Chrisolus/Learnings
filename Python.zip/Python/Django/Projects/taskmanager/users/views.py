from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import RegisterSerializer
from rest_framework_simplejwt.tokens import RefreshToken

class MyUserView(APIView):

    def get(self, request):
        return Response({'msg':'API Endpoint for users'})
    

class RegisterView(APIView):

    def get_token(self, user):
        token = RefreshToken.for_user(user)
        return {
            "refresh": str(token),
            "access": str(token.access_token),
            "user":str(user)
        }

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            token = self.get_token(user)
            return Response(token,status=200)
        else:
            return Response(serializer.errors, status=400)

