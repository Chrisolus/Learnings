from django.db import models
from django.contrib.auth.models import User

class Task(models.Model):

    STATUS_COICES = [
        ("pending", "Pending"),
        ("in-progress", "In Progress"),
        ("completed", "Completed"),
    ]

    PRIORITY_COICES = [
        ("low", "Low"),
        ("medium", "Medium"),
        ("high", "High"),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField()
    priority = models.CharField(max_length=10, choices=PRIORITY_COICES, default="low")
    status = models.CharField(max_length=15, choices=STATUS_COICES, default="pending")
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='tasks', default=1)