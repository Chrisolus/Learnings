class A:
    def display(self):
        print("This is A")

class B:
    def display(self):
        print("This is B")
    def display2(self):
        print("Display2 of B")

class C:
    def display(self):
        print("This is C")

class D(A,B):
    def display(self):
        super().display2()
        print("This is D")

d = D()
b