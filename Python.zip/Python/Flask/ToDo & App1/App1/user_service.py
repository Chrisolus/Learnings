from database import SqliteDB

mydb = SqliteDB('database.db')

def login(username, email):
    query = f"SELECT * FROM users WHERE username = ? AND email = ?"
    return mydb.fetch_one(query, (username, email))

def add_user(username, email):
    query ="INSERT OR IGNORE INTO users (username, email) VALUES (?, ?)"
    return mydb.add_data(query, (username, email))

def delete_user(id):
    query = "DELETE FROM users WHERE id = ?"
    return mydb.delete_data(query, (id,))

def getuserlist():
    return mydb.fetch_all()