from flask import Flask, redirect, url_for, render_template, session, request, flash
import user_service 

app = Flask(__name__)
app.secret_key = "lokijuhy"

@app.errorhandler(404)
def handle_error(error):
    return render_template("error.html", error=error)

@app.route('/profile')
def profile():
    if "username" in session:
        return render_template('profile.html', user = session['username'])
    else:
        flash("Login to your profile")
        return redirect(url_for("login"))

@app.route("/users", methods = ['GET', 'POST'])
def getusers():
    if request.method == "POST":
        result = user_service.delete_user(request.form['user_id'])
        if result:
            flash("Deleted successfully")
        else:
            flash("Cannot delete the user")
        return redirect(url_for('getusers'))
    else:
        if "username" in session:
            users = user_service.getuserlist()
            flash(f"{len(users)} item(s) fetched")
            return render_template("users.html", users = users)
        else:
            flash(f"Login to view all users")
            return redirect(url_for("login"))
    

@app.route('/adduser', methods = ["POST", "GET"])
def adduser():
    if request.method == 'POST':
        result = user_service.add_user(*request.form.values())
        print("result", result)
        if result:
            flash(f"User added successfully @{result}")
            return redirect(url_for('getusers'))
        else:
            flash(f"Cannot add user")
            return render_template("adduser.html")
    
    else:
        return render_template("adduser.html")

@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        username , email = request.form.values()
        user = user_service.login(username, email)
        if user:
            session['username'], session["email"]= user[1:]
            print("res", type(user))
            return redirect(url_for('profile'))
        else:
            flash(f"No user found {username}")
            return redirect(url_for("login"))
        
    else:
        if 'username' in session:
            return redirect(url_for('profile'))
        else:
            return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("username", None)
    session.pop("email", None)
    flash("You have been logged out!")
    return redirect(url_for('login'))

@app.route("/home")
def index():
    name = None
    if "username" in session:
        name = session["username"]
    return render_template("home.html", name=name)


if __name__ == "__main__":
    app.run(debug=True)
