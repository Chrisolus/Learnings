from flask import Blueprint, render_template, redirect, url_for, request, flash
from database import db, Task

app_route = Blueprint("app_route", __name__)

@app_route.route("/")
def index():
    tasks = [
        {"id": task.id, "task_description": task.task_description}
        for task in Task.query.all()
    ]
    flash(f"{len(tasks)} tasks fetched")
    return render_template('index.html', tasks = tasks)

@app_route.route("/add_task", methods=["POST"])
def addtask():
    try:
        task = Task(task_description = request.form['task'])
        db.session.add(task)
        db.session.commit()
        flash(f"Task added ({request.form['task']})")
    except Exception as e:
        flash(f"Error Occured: {e}")
    return redirect(url_for("app_route.index"))

@app_route.route("/delete", methods=['POST'])
def delete():
    task = Task.query.get(request.form['id'])  # Fetch the task by ID

    if not task:
        flash(f"Task not found")
    else:
        db.session.delete(task)  # Delete from the database
        db.session.commit()
        flash(f"Task ({request.form['id']}) deleted!")


    return redirect(url_for("app_route.index"))

@app_route.route("/<name>")
def anything(name):
    return redirect(url_for("app_route.index"))