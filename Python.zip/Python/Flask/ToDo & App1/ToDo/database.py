from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Task(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    task_description = db.Column(db.String(500), nullable = False)

def init_db(app):
    try:
        db.init_app(app)
        with app.app_context():
            db.create_all()
        print("DB initiated")
    except Exception as e:
        print(e)