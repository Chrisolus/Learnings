def read_numbers(file_path):
    with open(file_path, "r") as file:
        for line in file:
            for num in line.split():
                yield int(num)  # Yield each number lazily

# Call the generator function
numbers = read_numbers("demo1.py")
