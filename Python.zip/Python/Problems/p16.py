ranked = [100, 100, 50, 40, 40, 20, 10]

players = [5, 25, 50, 120]

ranked = sorted(set(ranked), reverse=True)

rank = len(ranked)

ranks = []

for score in players:
    while rank > 0 and score >= ranked[rank - 1]:
        rank-=1
    ranks.append[rank+1]

print(rank)