def checkPassword(p):

    spcl = "!@#$%^&()+-"

    has_digit = any(c.isdigit() for c in p)
    has_lower = any(c.islower() for c in p)
    has_upper = any(c.isupper() for c in p)
    has_spcl = any(c in spcl for c in p)
    req_len = max(0, 6 - len(p))

    return max(req_len, 4- sum([has_digit, has_lower, has_upper, has_spcl]))


p = "2bbbb"
# p = "2bb#A"

print(checkPassword(p))