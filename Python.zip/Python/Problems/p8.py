def pageCount(n, p):
    if n%2 == 0:
        tot =(n+2)// 2
    else:
        tot = (n+1)//2

    if tot - p <= 0:
        return tot - (p//2 +1)
    else:
        return p//2

print(pageCount(6, 2)) #1
print(pageCount(6, 5)) #1
print(pageCount(5, 3)) #1
print(pageCount(5, 4)) #0
print(pageCount(10, 4)) #2
print(pageCount(9, 6)) #1



