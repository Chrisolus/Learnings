arr = [1,2,3,4,5,4,3,2,1,3,4]
import demo

type_count = {}

for i in demo.numbers:
    if i in type_count:
        type_count[i] += 1
    else:
        type_count[i] = 1

max_keys = [k for k, v in type_count.items() if v == max(type_count.values())]

print(min(max_keys))
# print(max(type_count, key = type_count.get))
