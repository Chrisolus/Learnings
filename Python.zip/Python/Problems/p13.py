n = 6
k = 3
ar = [1, 3, 2, 6, 1, 2]

i = count = 0
j = 1
while i<len(ar)-1:

    if (ar[i] + ar[j]) % k == 0:
        count +=1

    if j+1 >= len(ar):
        i+=1
        j = i+1
    else:
        j+=1

print(count)