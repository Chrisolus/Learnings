def one_edit(s1, s2):

    if len(s1) > len(s2):
        s1, s2 = s2, s1 
    if len(s2) - len(s2) > 1:
        return False
    
    i = j = 0
    fd = False

    while i<len(s1) and j<len(s2):
        if s1[i] != s2[j]:
            if fd:
                return False
            fd = True

            if len(s1) == len(s2):
                i+=1
        else:
            i+=1
        j+=1
    
    return True

print(one_edit("Pale", "Pal"))
print(one_edit("Pale", "Palo"))
print(one_edit("Pale", "Balo"))
print(one_edit("Pale", "Bal"))

