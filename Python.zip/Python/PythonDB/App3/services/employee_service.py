from validators import getValidId, getValidField, getValidValue, getValidDate, wait

class EmployeeService: # Handles User Input and Validations before sendng data to Employee 
    def __init__(self, employee):
        self.emp = employee

    def addEmployee(self):
        res = self.emp.create()
        if res.get("message"):
            print(res.get("message"))
        else:
            self.printEmployee(res)
        wait()

    def viewEmployee(self):
        while True:
            print("===== VIEW EMPLOYEE =====")
            print("1. View by ID")
            print("2. View by Field")
            print("3. View All")
            print("4. Back")
            print("="*25,)
            c = input("choice>>>")
            if c == "1":
                id = getValidId(self.emp.table)
                self.printEmployee(self.emp.fetchById(id)) 
            elif c == "2":
                field = getValidField(self.emp.table)
                if field == "role":
                    value = None
                else:
                    value = getValidValue(f"Enter {field}>> ")
                self.printEmployee(self.emp.fetchBy(field, value))
            elif c == "3":
                self.printEmployee(self.emp.fetchAll())
            elif c == "4":
                break
            else:
                print("Invalid Choice :: Try [1-4]")
            wait()
    
    def updateEmployee(self):
        self.printEmployee(self.emp.fetchAll())
        print("===== UPDATE EMPLOYEE =====")
        id = getValidId(self.emp.table)
        field = getValidField(self.emp.table)
        
        if field == 'role':
            value = None
        elif field == 'dob':
            value = getValidDate()
        else: 
            value = getValidValue(f"Enter {field}>> ")
        self.printEmployee(self.emp.updateField(id, field, value))
        wait()

    def deleteEmployee(self):
        self.printEmployee(self.emp.fetchAll())
        print("===== DELETE EMPLOYEE =====")
        id = getValidId(self.emp.table)
        res = self.emp.delete(id)
        if res.get("message"):
            print(res.get('message'))
        else:
            self.printEmployee(self.emp.fetchAll())
            print(f"{'='*8} {res.get('rows')} Row Deleted Successfully {'='*9}")
        wait()

    @staticmethod
    def printEmployee(employees: dict):
        if employees.get("employees"):
            employees = employees.get("employees")
            print(f"{'='*70}\n{" "*31}EMPLOYEE\n{'='*70}")
            print(f"{'ID':<5} {'Name':<20} {'DOB':<12} {'Role':<20} {'Salary':<15}")
            print("=" * 70)
            try:
                for emp in employees:
                    emp_id, fname, lname, dob, role, salary = emp
                    name = f"{fname} {lname}"
                    print(f"{emp_id:<5} {name:<20} {dob:<12} {str(role):<20} {str(salary):<10}")
                print("=" * 70) 
            except Exception as e:
                print(e)
        elif employees.get('message'):
            print(employees.get("message"))
        else:
            print("Requested employee record is missing or does not exist.")
