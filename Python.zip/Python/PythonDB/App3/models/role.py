from validators import getValidValue

class Role: # Handles CRUD operations on Role Table
    def __init__(self, connection):
        self.con = connection
        self.table = "Role"
    
    def create(self):
        print("==CREATE ROLE==")
        data = Role.getInput()
        try:
            cursor = self.con.cursor()
            cursor.execute("INSERT INTO Role (key, name, salary) VALUES (?,?,?)", tuple(data.values()))
            self.con.commit()
            return self.fetchById(cursor.lastrowid)
        except Exception as e:
            return {'message': str(e)}
        
    def fetchById(self, id):
        try:
            cursor = self.con.cursor() 
            cursor.execute(f"SELECT * FROM Role WHERE id = {id}")
            return {"roles": (cursor.fetchone(),)}
        except Exception as e:
            return {'message': str(e)}
    
    def fetchAll(self):
        try:
            cursor = self.con.cursor()
            cursor.execute("SELECT * FROM Role")
            return {"roles" : cursor.fetchall()}
        except Exception as e:
            return {'message': str(e)}
        
    def updateField(self, id, field, value):
        try:
            cursor = self.con.cursor()
            cursor.execute( f"UPDATE Role SET {field} = ? WHERE id = ?", (value, id, ))
            self.con.commit()
            if cursor.rowcount <= 0:
                raise Exception({'message': 'No rows affected'})
            else:
                return self.fetchById(id)
        except Exception as e:
            return {'message': str(e)}
    
    def delete(self, id):
        print(self.fetchById(id))
        while not (c := input("Do you want to delete the above? (y/n)>> ")).lower() == 'y' and not c.lower() == 'n': 
            print("Invalid Input")
        if c.lower() == 'y':
            cursor = self.con.cursor()
            cursor.execute("DELETE FROM Role WHERE id = ?", (id,))
            self.con.commit()
            return {"rows" : cursor.rowcount}
        else:
            return {'message': 'Operation Aborted'}
        
    def getKeyId(self, key):
        try:
            cursor = self.con.cursor()
            cursor.execute("SELECT id FROM Role WHERE key = ?", (key,))
            return cursor.fetchone()
        except Exception as e:
            print("Error: ", str(e))
            return None
        
    def fetchKeys(self):
        try:
            cursor = self.con.cursor()
            cursor.execute("SELECT key FROM Role")
            return tuple(item[0] for item in cursor.fetchall()) 
        except Exception as e:
            print("Error: ", str(e))
            return None
        
    def getValidRoleKey(self, prompt):
        while True:
            role = input(prompt)
            if len(role) >3:
                print("Keyword cannot have more than 3 letters")
                continue
            if role in Role.getKeys():
                print("Role already present")
                continue
            if not role.strip():
                print("Invalid Key")
                continue
            break
        return role

    def getValidRoleId(self):
        while not (role_id := self.getKeyId(input("Employee Role (key)>> "))):
            print(f"Invalid Key :: Valid Roles -> {self.fetchKeys()}")
        return role_id

    def getInput(self):
        key = self.getValidRoleKey("Role Keyword>>")
        name = getValidValue("Role Name>> ")
        while not (salary := input("Role Salary>> ")).isdigit():
            print("Salary should be a number")
        
        return {'key': key, 'name': name, 'salary': salary}
