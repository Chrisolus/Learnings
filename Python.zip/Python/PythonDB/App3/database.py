import sqlite3
import atexit

class Database:

    _connection = None
    
    @staticmethod
    def init(): 
        con = Database.getConnection()
        
        cursor = con.cursor()

        cursor.execute("""CREATE TABLE IF NOT EXISTS Role (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        key TEXT UNIQUE NOT NULL,
                        name TEXT NOT NULL,
                        salary INTEGER NOT NULL)""")
        
        cursor.execute("""CREATE TABLE IF NOT EXISTS Employee (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fname TEXT NOT NULL,
                    lname TEXT NOT NULL,
                    dob TEXT NOT NULL,
                    role INTEGER,
                    FOREIGN KEY (role) REFERENCES Role(id) ON DELETE SET NULL)""")
        
        con.commit()
        print("Tables Initated Successfully")
        atexit.register(lambda: con.close())
        return con
    
    @staticmethod
    def getConnection():
        if Database._connection is None:
            Database._connection = sqlite3.connect("database.db", check_same_thread=False)
        Database._connection.execute("PRAGMA foreign_keys = ON")
        return Database._connection
    
    @staticmethod
    def fields(table):
        con = Database.getConnection()
        cursor = con.cursor()
        query = f"PRAGMA table_info({table})"
        cursor.execute(query)
        fields = tuple(item[1] for item in cursor.fetchall())
        return fields
    
    @staticmethod
    def getIds(table):
        con = Database.getConnection()    
        cursor = con.cursor()
        cursor.execute(f"SELECT id FROM {table}")
        return tuple(i[0] for i in cursor.fetchall())

# SELECT e.id, e.fname, e.lname, e.dob, r.name AS role, r.salary FROM Employee e LEFT JOIN Role r ON e.role = r.id WHERE e.id in (select id from Role where salary = '30000');
# SELECT e.id, e.fname, e.lname, e.dob, r.name AS role, r.salary FROM Employee e LEFT JOIN Role r ON e.role = r.id WHERE e.id in (select id from Role where role_key = 'AN');
