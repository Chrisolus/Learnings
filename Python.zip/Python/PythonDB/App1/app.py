import sqlite3

def connect_db():
    return sqlite3.connect("employees.db")

def create_tables():
    conn = connect_db()
    cursor = conn.cursor()
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS Role (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        key TEXT UNIQUE NOT NULL,
                        name TEXT NOT NULL,
                        salary INTEGER NOT NULL)''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS Employee (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        fname TEXT NOT NULL,
                        lname TEXT NOT NULL,
                        dob TEXT NOT NULL,
                        role_id INTEGER NOT NULL,
                        FOREIGN KEY (role_id) REFERENCES Role(id)) ON DELETE SET NULL''')
    
    conn.commit()
    conn.close()

def add_role(key, name, salary):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Role (key, name, salary) VALUES (?, ?, ?)", (key, name, salary))
    conn.commit()
    conn.close()

def add_employee(fname, lname, dob, role_key):
    conn = connect_db()
    cursor = conn.cursor()
    
    cursor.execute("SELECT id FROM Role WHERE key = ?", (role_key,))
    role = cursor.fetchone()
    if not role:
        print("Error: Role not found!")
        return
    
    cursor.execute("INSERT INTO Employee (fname, lname, dob, role_id) VALUES (?, ?, ?, ?)",
                   (fname, lname, dob, role[0]))
    conn.commit()
    conn.close()

def view_employees():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''SELECT e.id, e.fname, e.lname, e.dob, r.name, r.salary 
                      FROM Employee e 
                      JOIN Role r ON e.role_id = r.id''')
    employees = cursor.fetchall()
    conn.close()
    
    print("\nEmployees List:")
    for emp in employees:
        print(f"ID: {emp[0]}, Name: {emp[1]} {emp[2]}, DOB: {emp[3]}, Role: {emp[4]}, Salary: {emp[5]}")

def main():
    create_tables()
    while True:
        print("\nEmployee Management System")
        print("1. Add Role")
        print("2. Add Employee")
        print("3. View Employees")
        print("4. Exit")
        choice = input("Enter choice: ")
        
        if choice == "1":
            key = input("Enter role key: ")
            name = input("Enter role name: ")
            salary = int(input("Enter salary: "))
            add_role(key, name, salary)
        elif choice == "2":
            fname = input("Enter first name: ")
            lname = input("Enter last name: ")
            dob = input("Enter DOB (YYYY-MM-DD): ")
            role_key = input("Enter role key: ")
            add_employee(fname, lname, dob, role_key)
        elif choice == "3":
            view_employees()
        elif choice == "4":
            break
        else:
            print("Invalid choice! Try again.")

if __name__ == "__main__":
    main()
