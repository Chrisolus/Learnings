import sqlite3
import atexit

class Database:

    _connection = None

    @staticmethod
    def init():
        con = Database.getConnection()
        
        cursor = con.cursor()

        cursor.execute("""CREATE TABLE IF NOT EXISTS Role (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        key TEXT UNIQUE NOT NULL,
                        name TEXT NOT NULL,
                        salary INTEGER NOT NULL)""")
        
        cursor.execute("""CREATE TABLE IF NOT EXISTS Employee (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fname TEXT NOT NULL,
                    lname TEXT NOT NULL,
                    dob TEXT NOT NULL,
                    role INTEGER,
                    FOREIGN KEY (role) REFERENCES Role(id) ON DELETE SET NULL)""")
        
        
        con.commit()
        atexit.register(lambda: con.close())
        print("Tables Initated Successfully")
    
    @staticmethod
    def getConnection():
        if Database._connection is None:
            Database._connection = sqlite3.connect("database.db", check_same_thread=False)
        Database._connection.execute("PRAGMA foreign_keys = ON")
        return Database._connection
    
    @staticmethod
    def fields(table):
        query = f"PRAGMA table_info({table})"
        con = Database.getConnection()
        cursor = con.cursor()
        cursor.execute(query)
        fields = tuple(item[1] for item in cursor.fetchall())
        return fields
    
    @staticmethod
    def getIds(table):    
        cursor = Database._connection.cursor()
        cursor.execute(f"SELECT id FROM {table}")
        return tuple(i[0] for i in cursor.fetchall())