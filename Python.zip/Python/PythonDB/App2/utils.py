from datetime import datetime
from database import Database

def isValidDate(date_str):
    try:
        datetime.strptime(date_str, "%d/%m/%Y")
        return True 
    except Exception:
        return False

def getValidRoleKey():
    from role import Role
    while True:
        role = input("Role Keyword>> ")
        if len(role) >3:
            print("Keyword cannot have more than 3 letters")
            continue
        if role in Role.getKeys():
            print("Role already present")
            continue
        if not role.strip():
            print("Invalid Key")
            continue
        
        break
    return role

def getValidRoleId():
    from role import Role
    while not (role_id := Role.getKeyId(input("Employee Role (key)>> "))):
        print(f"Invalid Key :: Try {Role.getKeys()}")
    return role_id

def getValidValue(prompt):
    while not (name := input(f"{prompt}>> ")).strip():
            print("Invalid Value")
    return name

def getValidField(tablename):
    while not (field:= input(f"Enter {tablename} Field>> ")) in Database.fields(tablename):
        print(f"Invalid Field :: try {Database.fields(tablename)}")
    return field

def getValidId(tablename):
    while not (id := input(f"Enter {tablename} id>> ")).isdigit() or not (int(id) in Database.getIds(tablename)):
        print("Invalid ID")
    return id

def getValidDate():
    while not isValidDate(date:=input("Employee dob (dd/mm/yyyy)>> ")):
        print("Invalid format. Try dd/mm/yyyy")
    return date

getFields = lambda tablename: Database.fields(tablename)
