from database import Database
import utils

con = Database.getConnection()

class Employee():
    
    select_query = "SELECT e.id, e.fname, e.lname, e.dob, r.name, r.salary FROM Employee e LEFT JOIN Role r ON e.role = r.id"

    @staticmethod
    def create():
        print("==CREATE EMPLOYEE==")
        data = Employee.getUserInput()
        try:
            cursor = con.cursor()
            cursor.execute("INSERT INTO Employee (fname, lname, dob, role) VALUES (?,?,?,?)", tuple(data.values()))
            con.commit()
            return Employee.fetchById(cursor.lastrowid)       
        except Exception as e:
            return {'message': str(e)}

    @staticmethod
    def fetchAll():
        try:
            cursor = con.cursor() 
            cursor.execute(Employee.select_query)
            return {'employees': cursor.fetchall()}
        except Exception as e:
            return {'message': str(e)}
        
    @staticmethod
    def fetchById(id):
        try:
            cursor = con.cursor() 
            cursor.execute(f"{Employee.select_query} WHERE e.id = ?", (id,))
            return {"employees": (cursor.fetchone(),)}
        except Exception as e:
            return {'message': str(e)}

    @staticmethod
    def fetchBy(field, value):
        if field in Database.fields('Employee'):
            try:
                cursor = con.cursor()
                cursor.execute(f"{Employee.select_query} WHERE e.{field} = ?", (value,))
                return {'employees': cursor.fetchall()}
            except Exception as e:
                return {'message': str(e)}
        else:
            return {'message': 'Invalid Key'}
    
    @staticmethod
    def updateField(id, field, value):
        try:
            cursor = con.cursor()
            cursor.execute(f"UPDATE Employee SET {field} = ? WHERE id = ?", (value, id,))
            con.commit()

            if cursor.rowcount <=0:
                raise Exception("No rows affected")
            else:
                return Employee.fetchById(id)
        except Exception as e:
            return {'message': str(e)}

    @staticmethod
    def delete(id):
        try:    
            cursor = con.cursor()
            cursor.execute("DELETE FROM Employee WHERE id = ?", (id,))
            con.commit()
            if cursor.rowcount <=0:
                raise Exception("No rows affected")
            else:
                return {"rows" : cursor.rowcount}
        except Exception as e:
            return {'message': str(e)}
    
    @staticmethod    
    def getUserInput():
        fname = utils.getValidValue("Employee first name>> ")
        lname = utils.getValidValue("Employee last name>> ")
        dob = utils.getValidDate()
        role_id = utils.getValidRoleId()
        
        return {'fname': fname, 'lname': lname, 'dob': dob, 'role_id': role_id[0],}
    
    