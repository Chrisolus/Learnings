def short_string(s):
    for i in range(1, len(s)):
        if s[i] == s[i-1]:
            return short_string(s[:i-1]+s[i+1:])
        
    return s
        

s = "aaabccddd"
print(short_string(s))
# i = 8
# print(s[0:i]+s[i+1:])



# found = False
# for i in range(0, len(s)-1):
#     if s[i] == s[i+1]:
#         print(s[0:i]+s[i+1:])

