x = 1
y = 3
z = 2

if abs(y-z) == abs(x-z):
    print("Mouse C")

if abs(y-z) > abs(x-z):
    print("Cat A")
else:
    print("Cat B")