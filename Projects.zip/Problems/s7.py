sos = "SOSSPSSQSSOR"

s_count = len(sos)//3 * 2
o_count = len(sos)//3

extra_chars = len(sos) % 3  

if extra_chars >= 1:  
    s_count += 1
if extra_chars == 2: 
    o_count += 1

print(s_count - sos.count("S") + o_count - sos.count("O"))




