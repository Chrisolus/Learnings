from itertools import combinations

s = "beabeefeab"

unique_chars = set(s)

for c1,c2 in combinations(unique_chars, 2):
    filtered_string = [c for c in s if c in (c1, c2)]
    if all(s[i] != s[i+1] for i in range(len(s) - 1)):
        maxlen = max(maxlen , len(filtered_string))
print(maxlen)