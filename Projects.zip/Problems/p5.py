def roundOff(grades):
    round_off = []
    for grade in grades:
        if grade < 38:
            round_off.append(grade)
            continue

        diff = 5 - grade%5 

        if diff >= 3 or diff == 0:
            round_off.append(grade)  
            continue
        else:
            round_off.append(grade + diff)
            continue
    return round_off
 
print(roundOff([73,67,38,33,80])) #75
# print(roundOff(67)) #67
# print(roundOff(38)) #40
# print(roundOff(33)) #33
# print(roundOff(80)) #80 
