def angryProfessor(k, a):
    # Write your code here
    attendance = sum(1 for i in a if i<=0)
    return "NO" if attendance==k else "Yes"

# k = 3
# a = [-1, -3, 4, 2]

k = 2
a = [0, -1, 2, 1]

print(angryProfessor(k, a))