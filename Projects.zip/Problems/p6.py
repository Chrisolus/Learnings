def count(s, t, a, b, apples, oranges):
    a_cord = (a+i for i in apples)
    o_cord = (b+i for i in oranges)
    a_count = o_count = 0

    for apple, orange in zip(a_cord, o_cord):
        if apple in range(s, t+1):
            a_count +=1

        if orange in range(s, t+1):
            o_count+=1

    print(f"{a_count}\n{o_count}")
        

count(7, 10, 4, 12, [2,3,-4], [3,-2,-4])