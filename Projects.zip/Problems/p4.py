def roundOff(rank):
    if rank < 38:
        return rank
    
    if rank % 5 == 0:
        return rank 
    else:
        next_multiple = (rank//5 + 1) * 5

        if next_multiple - rank <3:
            return next_multiple
        else:
            return rank
        
# 4
# 73
# 67
# 38
# 33
print(roundOff(73))
print(roundOff(67))
print(roundOff(38))
print(roundOff(33))



