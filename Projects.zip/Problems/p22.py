# k = 2
# a = [1, 2, 3]
# queries = [0,1,2]

a = [1,2,3,4,5]
k = 7
queries = [0,1,2,3]

k = k%len(a)

for pos in queries:
    print(a[(pos+(len(a)-k))%len(a)])
