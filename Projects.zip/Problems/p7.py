def bonAppetit(bill, k, b):
    b_actual = 0
    for i in range(len(bill)):
        if i!=k:
            b_actual += bill[i]
    
    b_actual//=2

    return "Bon Appetit" if b==b_actual else b - b_actual


print(bonAppetit([3,10,2,9], 1, 12))