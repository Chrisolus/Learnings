from django.shortcuts import render, redirect
from django import views
from datetime import datetime
import requests
from django.views.decorators.http import require_POST, require_GET
from django.contrib import messages

API_URL = "http://127.0.0.1:8000/api"

formatTime = lambda blog: {
    **blog,
    "created_at": datetime.strptime(
        blog["created_at"], "%Y-%m-%dT%H:%M:%S.%fZ"
    ).strftime("%d-%b-%Y %I:%M %p"),
}

@require_POST
def get_refreshed(refresh): # To refresh JWT stored in session
    try:
        response = requests.post(
            f"{API_URL}/users/refresh/",
            json={"refresh": refresh},
        )
        if response.status_code == 200:
            return {"refresh": refresh, "access": response.json().get("access")}
        else:
            return response.raise_for_status()
    except Exception as e:
        print(e)
        return None

@require_GET
def home(request): 
    data = None
    try: # Fetch all the blogs and list them
        response = requests.get(f"{API_URL}/blogs/")
        if response.status_code == 200:
            blogs = response.json()
            blogs = list(map(formatTime, blogs))
            data = {"blogs": blogs} # Accessed fields: Title & author - Endpoint can be optimized to return only the required values
        else:
            response.raise_for_status()
    except requests.exceptions.RequestException as e:
        messages.error(request, e)

    return render(request, "home.html", {"data": data})

@require_POST
def logout(request):
    if not request.session.get("tokens"):
        messages.success(request, "You are not logged in")
        return redirect("login-page")

    try: # To blacklist the token ensuring the deactivation of tokens
        response = requests.post(
            f"{API_URL}/users/logout/",
            json={"refresh": request.session["tokens"]["refresh"]},
        )
        if response.status_code == 200:
            request.session.flush()
            messages.info(request, "You are logged out")
        else:
            response.raise_for_status()
    except requests.exceptions.RequestException as e:
        messages.error(request, e)
    return redirect("home-page")

# Authentication Class - common for both login and register - same data is returned
class AuthCredentialsView(views.View):
    def post(self, request):
        post_to = request.POST.get("submit")
        body = {
            "username": request.POST.get("username"),
            "email": request.POST.get("email"),
            "password": request.POST.get("password"),
        }
        response = requests.post(
            f"{API_URL}/users/{post_to}/",
            json=body,
        )
        if response.status_code == 200:
            request.session["tokens"] = response.json()
            messages.success(request, "You are logged in!")
            return redirect("myblogs-page")
        else:
            messages.error(request, "Invalid credentials. Please try again.")
            return redirect(f"{post_to}-page")


class RegisterView(AuthCredentialsView):
    def get(self, request):
        if not request.session.get("tokens"):
            return render(request, "register.html")
        messages.info(request, "You are already logged in")
        return redirect("myblogs-page")


class LoginView(AuthCredentialsView):
    def get(self, request):
        if not request.session.get("tokens"):
            return render(request, "login.html")
        messages.info(request, "You are already logged in")
        return redirect("myblogs-page")


# Fetch blogs created by the current user by validating the auth token
class MyBlogsView(views.View):
    def get(self, request):
        if not request.session.get("tokens"):
            messages.error(request, "You have to login to view your blogs")
            return redirect("login-page")
        try: # accessed fields: Title, author, created_at - endpoint can be optimized to return only the required values
            response = requests.get(
                f"{API_URL}/blogs/me/",
                headers={
                    "Authorization": f"Bearer {request.session["tokens"].get("access")}"
                },
            )
            if response.status_code == 200:
                data = {"blogs": list(map(formatTime, response.json()))}
                return render(request, "myblogs.html", {"data": data}) 

            if response.status_code == 401:
                tokens = get_refreshed(request.session["tokens"].get("refresh"))
                if tokens:
                    request.session["tokens"] = tokens
                    return redirect("myblogs-page")
                else:
                    request.session.flush()
                    messages.info(request, "Session expired")
                    return redirect("login-page")

        except requests.exceptions.RequestException as e:
            messages.error(request, f"Failed to fetch data: {e}")
            return redirect("home-page")

# Post blogs after validating the token 
class PostBlogView(views.View):
    def get(self, request):
        if not request.session.get("tokens"):
            messages.info(request, "Please login to post blogs")
            return redirect("login-page")
        return render(request, "postblog.html")

    def post(self, request):
        if not request.session.get("tokens"):
            messages.error(request, "Please login to post blogs")
            return redirect("login-page")

        try:
            response = requests.post(
                f"{API_URL}/blogs/add-post/",
                json={
                    "title": request.POST.get("title"),
                    "body": request.POST.get("body"),
                },
                headers={
                    "Authorization": f"Bearer {request.session["tokens"].get("access")}"
                },
            )
            if response.status_code == 200:
                messages.success(request, "Blog created successfully")
                return redirect("blog-detail-page", blog_id=response.json()["id"])
            elif response.status_code == 401:
                tokens = get_refreshed(request.session["tokens"].get("refresh"))
                if tokens:
                    request.session["tokens"] = tokens
                    return self.post(request)
                else:
                    request.session.flush()
                    messages.info(request, "Session expired. Try logging-in again")
            else:
                response.raise_for_status()
        except requests.exceptions.RequestException as e:
            messages.error(request, e)
        return redirect("post-page")

# Handles post request from blogDetails (Comments and Edits if editable)
class BlogDetailView(views.View):

    def get(sef, request, blog_id):
        if not request.session.get("tokens"):
            messages.info(request, "Login to read blogs")
            return redirect("login-page")
        try:
            response = requests.get(
                f"{API_URL}/blogs/{blog_id}/",
                headers={
                    "Authorization": f"Bearer {request.session["tokens"].get("access")}"
                },
            )
            if response.status_code == 200:
                blog = formatTime(response.json())
                return render(
                    request,
                    "editblog.html" if blog["editable"] else "blog.html",
                    {"blog": blog},
                )
            elif response.status_code == 401:
                tokens = get_refreshed(request.session["tokens"].get("refresh"))
                if tokens:
                    request.session["tokens"] = tokens
                    return redirect("blog-detail-page", blog_id)
                else:
                    request.session.flush()
                    messages.info(request, "Session expired. Try logging-in again")
                    return redirect("login-page")
            else:
                response.raise_for_status()
        except requests.exceptions.RequestException as e:
            messages.error(request, f"Failed to fetch data: {e}")
        return redirect("myblogs-page")

    def post(self, request, blog_id):
        if not request.session.get("tokens"):
            messages.info("Please login")
            return redirect("login-page")
        try:
            if request.POST.get("submit") == "comment":
                apiurl = f"{API_URL}/blogs/{blog_id}/comments/"
                body = {"text": request.POST.get("text")}
            else:
                apiurl = f"{API_URL}/blogs/{blog_id}/"
                body = {
                    "title": request.POST.get("title"),
                    "body": request.POST.get("body"),
                }
            
            response = requests.post(
                apiurl,
                json=body,
                headers={
                    "Authorization": f"Bearer {request.session["tokens"].get("access")}"
                },
            )

            if response.status_code == 200:
                messages.success(request, "Updated!")
            elif response.status_code == 401:
                tokens = get_refreshed(request.session["tokens"].get("refresh"))
                if tokens:
                    request.session["tokens"] = tokens
                    return self.post(request, blog_id)
                else:
                    request.session.flush()
                    messages.info(request, "Session expired. Try logging-in again")
                    return redirect("login-page")
            else:
                response.raise_for_status()
        except requests.exceptions.RequestException as e:
            messages.error(request, e)

        return redirect("blog-detail-page", blog_id)

# Handles deletion of the blog after validating the current user
class DeleteBlog(views.View):
    def post(self, request, blog_id):
        if not request.session.get("tokens"):
            messages.info("Please login")
            return redirect("login-page")
        try:
            response = requests.delete(
                f"{API_URL}/blogs/{blog_id}/",
                headers={
                    "Authorization": f"Bearer {request.session["tokens"].get("access")}"
                },
            )
            if response.status_code == 204:
                messages.success(request, "Deleted!")
                return redirect("myblogs-page")
            elif response.status_code == 401:
                tokens = get_refreshed(request.session["tokens"].get("refresh"))
                if tokens:
                    request.session["tokens"] = tokens
                    return self.post(request, blog_id)
                else:
                    request.session.flush()
                    messages.info(request, "Session expired. Try logging-in again")
                    return redirect("login-page")
            else:
                response.raise_for_status()
        except requests.exceptions.RequestException as e:
            messages.error(request, e)
        return redirect("blog-detail-page", blog_id)
