from django.urls import path
from .views import home, logout, BlogDetailView, LoginView, RegisterView, MyBlogsView, PostBlogView, DeleteBlog

urlpatterns = [
    path('home/', home, name="home-page"),
    path('blog-detail/<int:blog_id>', BlogDetailView.as_view(), name="blog-detail-page"),
    path('blog-detail/<int:blog_id>/delete', DeleteBlog.as_view(), name="blog-delete-page"),
    path('myblogs/', MyBlogsView.as_view(), name="myblogs-page"),
    path('post-blog/',PostBlogView.as_view(), name="post-page"),
    path('login/', LoginView.as_view(), name="login-page"),
    path('register/', RegisterView.as_view(), name="register-page"),
    path('logout/', logout, name='logout-page'),
]
