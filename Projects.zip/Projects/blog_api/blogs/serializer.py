from rest_framework import serializers
from .models import Blog, Comment

class CommentSerializer(serializers.ModelSerializer):
    author = serializers.CharField(source="author.username", read_only=True) 
    class Meta:
        model = Comment
        fields = "__all__"
        extra_kwargs = {
            "author": {"read_only": True},
            "blog": {"read_only": True},
            "created_at": {"read_only": True},
        }

class BlogSerializer(serializers.ModelSerializer):

    editable = serializers.SerializerMethodField()
    author = serializers.CharField(source="author.username") 
    comments = CommentSerializer(many=True, read_only=True)

    class Meta:
        model = Blog 
        fields = "__all__"
        extra_kwargs = {
            'id': {'read_only': True},  # Ensure id is not required during POST
            'author': {'read_only': True},  # Author should be derived from request.user
            'created_at': {'read_only': True}  # Auto-generated on creation
        }
        
    def get_editable(self, obj):
        user = self.context.get("user")
        return str(user) == str(obj.author) if user else False
    