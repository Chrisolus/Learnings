from django.urls import path
from .views import BlogsView, BlogById, PostBlogView, CommentView, MyBlogs

urlpatterns = [
    path('', BlogsView.as_view(), name="blogs-endpoint-view"),
    path('me/',MyBlogs.as_view(), name="user-blogs-view"),
    path('<int:blog_id>/', BlogById.as_view(), name="blogs-by-id-view"),
    path('<int:blog_id>/comments/', CommentView.as_view(), name="blogs-comments-view"),
    path('add-post/', PostBlogView.as_view(), name="blog-post-view"),
]
