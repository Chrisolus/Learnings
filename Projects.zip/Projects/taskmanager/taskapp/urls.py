from django.urls import path
from .views import GetTaskView, TaskByIDView, AddTaskView

urlpatterns = [
    path("", GetTaskView.as_view(), name="task-list-view"),
    path("<int:task_id>/", TaskByIDView.as_view(), name="task-id-view"),
    path("add-task/", AddTaskView.as_view(), name="task-add-app"),
]
