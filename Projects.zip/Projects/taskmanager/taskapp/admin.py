from django.contrib import admin
from .models import Task
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'priority','status','created_at','created_by')

class CustomUserAdmin(UserAdmin):
    list_display = ('id', 'username', 'is_staff')

admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)